import './Testimonial.css'
import next_icon from '../../assets/next-icon.png'
import back_icon from '../../assets/back-icon.png'
import user_1 from '../../assets/user-1.png'
import user_2 from '../../assets/user-2.png'
import user_3 from '../../assets/user-3.png'
import user_4 from '../../assets/user-4.png'
import { useRef } from 'react'

const Testimonial = () => {
    const slider = useRef();
    const tx = useRef(0); // persist value

    const Slideforward = () => {
        if (tx.current > -50) {
            tx.current -= 25;
            slider.current.style.transform =
                `translateX(${tx.current}%)`;
        }
    };

    const Slidebackward = () => {
        if (tx.current < 0) {
            tx.current += 25;
            slider.current.style.transform =
                `translateX(${tx.current}%)`;
        }
    };

    return (
        <div className='Testimonial'>

            <img
                src={next_icon}
                alt="Next"
                onClick={Slideforward}
                className='next-btn'
            />

            <img
                src={back_icon}
                alt="Back"
                onClick={Slidebackward}
                className='back-btn'
            />

            <div className="slider">
                <ul ref={slider}>

                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src={user_1} alt="User 1" className='user-img' />
                                <div>
                                    <h3>William Jackson</h3>
                                    <span>Edusity, USA</span>
                                </div>
                            </div>

                            <p>
                                Choosing to pursue my education at Edusity has been one of the best decisions of my life. The supportive community and excellent faculty have greatly enhanced my learning experience.
                            </p>
                        </div>
                    </li>

                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src={user_2} alt="User 2" className='user-img' />
                                <div>
                                    <h3>Emily Carter</h3>
                                    <span>Edusity, USA</span>
                                </div>
                            </div>

                            <p>
                                The instructors at Edusity are incredibly knowledgeable and passionate about teaching. They go above and beyond to ensure every student succeeds.
                            </p>
                        </div>
                    </li>

                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src={user_3} alt="User 3" className='user-img' />
                                <div>
                                    <h3>David Mitchell</h3>
                                    <span>Edusity, USA</span>
                                </div>
                            </div>

                            <p>
                                Edusity transformed my career path completely. The practical projects and real-world experience provided here are unmatched.
                            </p>
                        </div>
                    </li>

                    <li>
                        <div className="slide">
                            <div className="user-info">
                                <img src={user_4} alt="User 4" className='user-img' />
                                <div>
                                    <h3>Jessica Turner</h3>
                                    <span>Edusity, USA</span>
                                </div>
                            </div>

                            <p>
                                The best investment I ever made was my education at Edusity. The resources, mentorship, and community support exceeded expectations.
                            </p>
                        </div>
                    </li>

                </ul>
            </div>

        </div>
    )
}

export default Testimonial