import './Contact.css'
import msg_icon from '../../assets/msg-icon.png'
import mail_icon from '../../assets/mail-icon.png'
import phone_icon from '../../assets/phone-icon.png'
import location_icon from '../../assets/location-icon.png'

const Contact = () => {
  return (
    <div className='Contact'>
        <div className="contact-col">
           <h3>Send us a message  <img src={msg_icon} alt="Message Icon" /></h3>
           <p>Feel free to reach out to us with any questions or inquiries.
            Our team is here to assist you and provide the information you need. we look forward to hearing from you!
           </p>
           <ul>
            <li><img src={phone_icon} alt="Phone Icon" /><strong>Phone:</strong> +1 (123) 456-7890</li>
            <li><img src={mail_icon} alt="Email Icon" /><strong>Email:</strong> info@university.edu</li>
            <li><img src={location_icon} alt="Location Icon" /><strong>Address:</strong> 123 University Ave, City, State 12345</li>
           </ul>
        </div>
        <div className="contact-col">
            <form >
                <label >Your Name</label>
                <input type="text" name="name" placeholder='Enter your name' required/>
                <label >Your Email</label>
                <input type="email" name="email" placeholder='Enter your email' required/>
                <label >Your Message</label>
                <textarea name="message"  rows="10" placeholder='Enter your message' required></textarea>
                <button type="submit" className='btn dark-btn'>Send Message</button>
            </form>
        </div>
      
    </div>
  )
}

export default Contact
