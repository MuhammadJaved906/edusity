
import './Program.css'
import program_1 from '../../assets/program-1.png'
import program_2 from '../../assets/program-2.png'
import program_3 from '../../assets/program-3.png'
import icon_1 from '../../assets/program-icon-1.png'
import icon_2 from '../../assets/program-icon-2.png'
import icon_3 from '../../assets/program-icon-3.png'

const Program = () => {
  return (
    <div className='programs'>
        <div className="program">
            <img src={program_1} alt="Program 1" />
            <div className="caption">
                <img src={icon_1} alt="Icon 1" />
                <p>Graduation Degree</p>
            </div>
        </div>
        <div className="program">
            <img src={program_2} alt="Program 1" />
            <div className="caption">
                <img src={icon_2} alt="Icon 2" />
                <p>Masters  Degree</p>
            </div>
        </div>
        <div className="program">
            <img src={program_3} alt="Program 1" />
            <div className="caption">
                <img src={icon_3} alt="Icon 3" />
                <p>Post Graduation Degree</p>
            </div>
        </div>
      
    </div>
  )
}

export default Program
