import './Footer.css'

const Footer = () => {
  return (
    <footer className='Footer'>
      <div className='footer-wrapper'>
        <div className='footer-section'>
          <h3>About Edusity</h3>
          <p>Edusity is a leading educational platform dedicated to providing world-class learning experiences with innovative teaching methods and experienced instructors.</p>
          <div className='social-links'>
            <a href='#facebook' className='social-icon'>f</a>
            <a href='#twitter' className='social-icon'>𝕏</a>
            <a href='#linkedin' className='social-icon'>in</a>
            <a href='#instagram' className='social-icon'>📷</a>
          </div>
        </div>

        <div className='footer-section'>
          <h3>Quick Links</h3>
          <ul>
            <li><a href='#home'>Home</a></li>
            <li><a href='#about'>About Us</a></li>
            <li><a href='#programs'>Programs</a></li>
            <li><a href='#campus'>Campus</a></li>
            <li><a href='#contact'>Contact</a></li>
          </ul>
        </div>

        <div className='footer-section'>
          <h3>Programs</h3>
          <ul>
            <li><a href='#webdev'>Web Development</a></li>
            <li><a href='#datascience'>Data Science</a></li>
            <li><a href='#design'>UI/UX Design</a></li>
            <li><a href='#mobile'>Mobile Apps</a></li>
            <li><a href='#cloud'>Cloud Computing</a></li>
          </ul>
        </div>

        <div className='footer-section'>
          <h3>Contact Info</h3>
          <ul className='contact-info'>
            <li><strong>Email:</strong> <a href='mailto:info@edusity.com'>info@edusity.com</a></li>
            <li><strong>Phone:</strong> <a href='tel:+1234567890'>+1 (234) 567-890</a></li>
            <li><strong>Address:</strong> 123 Education St, Learning City, USA</li>
            <li><strong>Hours:</strong> Mon-Fri: 9 AM - 6 PM</li>
          </ul>
        </div>

        <div className='footer-section newsletter'>
          <h3>Newsletter</h3>
          <p>Subscribe to get updates on new courses and offers</p>
          <form className='newsletter-form'>
            <input type='email' placeholder='Your email' required />
            <button type='submit' className='btn'>Subscribe</button>
          </form>
        </div>
      </div>

      <div className='footer-bottom'>
        <p>&copy; 2024 Edusity. All rights reserved.</p>
        <div className='footer-links'>
          <a href='#privacy'>Privacy Policy</a>
          <span>|</span>
          <a href='#terms'>Terms of Service</a>
          <span>|</span>
          <a href='#sitemap'>Sitemap</a>
        </div>
      </div>
    </footer>
  )
}

export default Footer
