import { useEffect, useState } from 'react'
import { Link } from 'react-scroll'
import './Navbar.css'
import logo from '../../assets/logo.png'

const Navbar = () => {
  const[sticky, setSticky] = useState(false);
  useEffect(()=>{
    window.addEventListener("scroll",()=>{
      window.scrollY > 0 ? setSticky(true) : setSticky(false);
    })

  },[])

 
  return (
    <nav className={`container ${sticky ? 'dark-nav' : ''}`}>
      <img src={logo} alt="Logo" className='logo' />
      <ul>
        <li><Link to="hero container" smooth={true} offset={0} duration={500}>Home</Link></li>
        <li><Link to="programs" smooth={true} offset={0} duration={500}>Program</Link></li>
        <li><Link to="About" smooth={true} offset={0} duration={500}>About us</Link></li>
        <li><Link to="Campus" smooth={true} offset={0} duration={500}>Campus</Link></li>
        <li><Link to="Testimonial" smooth={true} offset={0} duration={500}>Testimonial</Link></li>
        <li><Link to="Contact" smooth={true} offset={0} duration={500}>Contact us</Link></li>
      </ul>
    </nav>
  )
}

export default Navbar
