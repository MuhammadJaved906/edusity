import Navbar from './components/Navbar/Navbar'
import Hero from './components/Hero/Hero'
import Program from './components/Programs/Program'
import Title from './components/Title/Title'
import About from './components/About/About'
import Campus from './components/Campus/Campus'
import Testimonial from './Components/Testimonial/Testimonial'
import Contact from './components/Contact/Contact'
import Footer from './Components/Footer/Footer'


const App = () => {
  return (
    <div>
      <Navbar />
      <Hero/>
      <div className="container">
        <Title  subtitle="Our Program" title="What We Offer"/>
        <Program/>
        <About/>
        <Title  subtitle="Gallery" title="Campus Photos"/>
        <Campus/>
        <Title  subtitle="Testimonials" title="What Our Students Say"/>
        <Testimonial/>
        <Title  subtitle="Contact us" title="Get In Touch"/>
        <Contact/>
        <Footer/>
       </div>
       
     </div>
  )
}
      

export default App
